package com.preproject.stackOverflow;

public class Uri {
}
