// 테스트페이지 입니다.

import Nav from '../component/Nav';

export default function Companies() {
  return (
    <div>
      <Nav />
    </div>
  );
}
