![image](https://github.com/codestates-seb/seb45_pre_026/assets/109846158/b50546b6-8116-4b0d-bf7f-c8e47199248c)
